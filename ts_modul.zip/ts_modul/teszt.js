function Rng(alsoHatar, felsoHatar) {
    var randomSzam = Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
    return randomSzam;
}
function TombGenerator(meret, alsoHatar, felsoHatar) {
    var generaltTomb = [];
    var probalkozasok = 0;
    while (probalkozasok < meret) {
        var generaltSzam = Math.round(Math.random() * (felsoHatar - alsoHatar) + alsoHatar);
        generaltTomb.push(generaltSzam);
        probalkozasok++;
    }
    return generaltTomb;
}
function Duplazo(VizsgaltTomb) {
    var VizsgaltTomb = [];
    var duplaTomb = [];
    for (var i = 0; i < VizsgaltTomb.length; i++) {
        var duplaErtek = VizsgaltTomb[i] * 2;
        duplaErtek.push(duplaTomb);
    }
    return duplaTomb;
}
function PrimekSzama(VizsgaltTomb) {
    var primekSzama = 0;
    var oszto = 0;
    for (var i = 0; i <= VizsgaltTomb.length; i++) {
        if (VizsgaltTomb[i] % i == 0) {
            oszto++;
        }
        if (oszto == 2) {
            primekSzama++;
        }
    }
    return PrimekSzama;
}
function EgyediElemek(VizsgaltTomb) {
    var primTomb = [];
    var oszto = 0;
    for (var i = 0; i <= VizsgaltTomb.length; i++) {
        if (VizsgaltTomb[i] % i == 0) {
            oszto++;
        }
        if (oszto == 2) {
            primTomb.push(primTomb);
        }
    }
    return PrimekSzama;
}
