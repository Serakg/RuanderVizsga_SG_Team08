function Rng(alsoHatar: number, felsoHatar: number): number {
    let randomSzam: number = Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
    return randomSzam;
}


function TombGenerator(meret: number, alsoHatar: number, felsoHatar: number): Array<number> {
    let generaltTomb = [];
    let probalkozasok: number = 0;
    while (probalkozasok < meret) {
        let generaltSzam: number = Math.round(Math.random() * (felsoHatar - alsoHatar) + alsoHatar);
        generaltTomb.push(generaltSzam);
        probalkozasok++
    }
    return generaltTomb
}


function Duplazo(VizsgaltTomb: Array<number>): Array<number> {
    let VizsgaltTomb = []
    let duplaTomb = []
    for (let i = 0; i < VizsgaltTomb.length; i++) {
        let duplaErtek = VizsgaltTomb[i] * 2;
        duplaErtek.push(duplaTomb)
    }
    return duplaTomb
}


function PrimekSzama(VizsgaltTomb: Array<number>):number {
    let primekSzama: number = 0;
    let oszto = 0;
    for (let i = 0; i <= VizsgaltTomb.length; i++) {
        if (VizsgaltTomb[i] % i == 0) {
            oszto++;
        }
    if (oszto == 2){
        primekSzama++;
    }
    }
    return PrimekSzama

}


function EgyediElemek(VizsgaltTomb: Array<number>):Array<number>{
    let primTomb = [];
    let oszto = 0;
    for (let i = 0; i <= VizsgaltTomb.length; i++) {
        if (VizsgaltTomb[i] % i == 0) {
            oszto++;
        }
    if (oszto == 2){
        
        primTomb.push(primTomb);
    }
    }
    return PrimekSzama

}
